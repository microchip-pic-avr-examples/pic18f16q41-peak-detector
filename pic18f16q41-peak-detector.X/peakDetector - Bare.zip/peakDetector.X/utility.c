#include "utility.h"

#include <xc.h>
#include <stdint.h>

const char hexLookup[]  = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

//Returns the remainder, and subtracts from the numerator during the division.
uint16_t inline fastDivide(uint16_t* numer, uint16_t divisor)
{
    uint16_t count = 0;
    while (*numer >= divisor)
    {
        *numer -= divisor;
        count++;
    }
    return count;
}

void initUART(void)
{    
    U1CON0 = 0x00;
    U1CON0bits.TXEN = 1;    //Enable TX
    U1CON0bits.BRGS = 1;    //Enable HS Baud rate for better accuracy at 1MHz
    
    U1CON1 = 0x00;
    U1CON2 = 0x00;
    
    U1BRG = 25;            //~9600 BAUD @ 1MHz
    
    TRISB7 = 0;
    RB7PPS = 0x10;          //U1TX
    
    U1CON1bits.ON = 1;      //Start the Port
}

void sendString(const char* str, uint8_t sendEOL)
{
    int index = 0;
    while (str[index] != '\0')
    {
        while (U1TXBF)
        {
            
        }
        
        asm("NOP");
        U1TXB = str[index];
        
        index++;
    }
    
    if (sendEOL == 0)
    {
        return;
    }
    
    END_OF_LINE;
}

void sendStringSafe(const char* str, int size)
{
    int index = 0;
    while (index < size)
    {
        while (U1TXBF)
        {
            
        }
        
        asm("NOP");
        U1TXB = str[index];  
        
        index++;
    }
}

void printRegisterLine(const char* str, uint8_t rg)
{
    sendString(str, 0);
    sendHexValue(rg);
    END_OF_LINE;
}

void printRegisterLineLarge(const char* str, uint16_t rg)
{
    sendString(str, 0);
    sendLargeHexValue(rg);
    END_OF_LINE;
}

void sendHexValue(uint8_t value)
{    
    char tx[2];
    
    tx[0] = hexLookup[value >> 4];
    tx[1] = hexLookup[(value & 0x0F)];
    
    sendStringSafe(&tx[0], 2);
}

void sendLargeHexValue(uint16_t value)
{
    char tx[4];
    
    tx[0] = hexLookup[(value >> 12)];
    tx[1] = hexLookup[((value >> 8) & 0x0F)];
    tx[2] = hexLookup[((value >> 4) & 0x0F)];
    tx[3] = hexLookup[(value & 0x0F)];
    
    sendStringSafe(&tx[0], 4);
}

void sendPeakValue(void)
{
    //With a 4.096V reference, every bit is 1mV
    //This is the value in mV
    uint16_t adc_peak = ADSTPT;
    char digit;
    
    //Warning for clipping signals
    if (adc_peak >= 0xFFF)
    {
        sendString("[WARN] Peak value is exceeding ADC measurement limits", 1);
    }
    
    sendString("Maximum Value: ", 0);
    
    if (adc_peak >= 1000)
    {
        //1000's place
        digit = '0' + fastDivide(&adc_peak, 1000);
        sendStringSafe(&digit, 1);
        sendStringSafe(".", 1);
        
        //100's place
        digit = '0' + fastDivide(&adc_peak, 100);
        sendStringSafe(&digit, 1);

        //10's place
        digit = '0' + fastDivide(&adc_peak, 10);
        sendStringSafe(&digit, 1);
        
        //1's place
        digit = '0' + adc_peak;
        sendStringSafe(&digit, 1);
        sendString("V", 1);
    }
    else
    {
        //mV range
        if (adc_peak >= 100)
        {
            digit = '0' + fastDivide(&adc_peak, 100);
            sendStringSafe(&digit, 1);
            
            digit = '0' + fastDivide(&adc_peak, 10);
            sendStringSafe(&digit, 1);
        }
        else if (adc_peak >= 10)
        {
            digit = '0' + fastDivide(&adc_peak, 10);
            sendStringSafe(&digit, 1);
        }
        digit = '0' + adc_peak;
        sendStringSafe(&digit, 1);
        sendString("mV", 1);
        
    }
}