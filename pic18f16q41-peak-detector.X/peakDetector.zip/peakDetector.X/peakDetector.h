/* 
 * File:   peakDetector.h
 * Author: C62081
 *
 * Created on May 7, 2020, 11:43 AM
 */

#ifndef PEAKDETECTOR_H
#define	PEAKDETECTOR_H

#ifdef	__cplusplus
extern "C" {
#endif

    typedef enum {PK_WAIT = 0, PK_OPEN, PK_RUNNING, PK_DONE} PEAK_STATES;
        
    //Control the state machine
    void setState(PEAK_STATES state);
    PEAK_STATES getState(void);

    //Send the peak value stored in ADSTPT (contained in the ADCC)
    void sendPeakValue(void);

#ifdef	__cplusplus
}
#endif

#endif	/* PEAKDETECTOR_H */

